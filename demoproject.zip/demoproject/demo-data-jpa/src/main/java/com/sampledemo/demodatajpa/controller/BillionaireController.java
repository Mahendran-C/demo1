package com.sampledemo.demodatajpa.controller;

import com.sampledemo.demodatajpa.model.Billionaire;
import com.sampledemo.demodatajpa.service.BillionaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BillionaireController {
    @Autowired
    private BillionaireService billionaireService;

    @GetMapping("/billionaire")
    public ResponseEntity<List<Billionaire>> fetchAllBillionaires(@RequestParam(required = false) String career, @RequestParam(required = false) String firstName) {
        if (!StringUtils.isEmpty(career)) return ResponseEntity.ok().body(billionaireService.getAllBillionairesByCareer(career));
        else if (!StringUtils.isEmpty(firstName)) return ResponseEntity.ok().body(billionaireService.getAllBillionairesByFirstName(firstName));
        else return ResponseEntity.ok().body(billionaireService.getAllBillionaires());
    }

    @GetMapping("/billionaire/{id}")
    public ResponseEntity<Billionaire> fetchBillionaireById(@PathVariable Integer id) {
        return billionaireService.getBillionaireById(id)
                .map(b -> ResponseEntity.ok().body(b))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/billionaire")
    public ResponseEntity<Billionaire> saveBillionaire(@RequestBody Billionaire billionaire) {
        return ResponseEntity.ok().body(billionaireService.saveBillionaire(billionaire));
    }

    @PutMapping("/billionaire")
    public ResponseEntity<Billionaire> updateBillionaire(@RequestBody Billionaire billionaire) {
        return ResponseEntity.ok().body(billionaireService.saveBillionaire(billionaire));
    }

    @DeleteMapping("/billionaire/{id}")
    public ResponseEntity<Void> deleteBillionaire(@PathVariable Integer id) {
        billionaireService.deleteBillionaireById(id);
        return ResponseEntity.ok().build();
    }
}

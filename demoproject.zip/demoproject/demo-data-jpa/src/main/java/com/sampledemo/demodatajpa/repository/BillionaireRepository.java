package com.sampledemo.demodatajpa.repository;

import com.sampledemo.demodatajpa.model.Billionaire;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BillionaireRepository extends JpaRepository<Billionaire, Integer> {

    List<Billionaire> findByFirstName(String firstName);
    List<Billionaire> findAllByCareer(String career);

    @Override
    void deleteById(Integer integer);
}

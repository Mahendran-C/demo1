package com.sampledemo.demodatajpa.service;

import com.sampledemo.demodatajpa.model.Billionaire;
import com.sampledemo.demodatajpa.repository.BillionaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class BillionaireService {
    @Autowired
    private BillionaireRepository billionaireRepository;

    public List<Billionaire> getAllBillionaires() {
        return billionaireRepository.findAll();
    }

    public List<Billionaire> getAllBillionairesByFirstName(String firstName) {
        return billionaireRepository.findByFirstName(firstName);
    }

    public List<Billionaire> getAllBillionairesByCareer(String career) {
        return billionaireRepository.findAllByCareer(career);
    }

    public Optional<Billionaire> getBillionaireById(Integer id) {
        return billionaireRepository.findById(id);
    }

    public Billionaire saveBillionaire(Billionaire billionaire) {
        return billionaireRepository.save(billionaire);
    }

    public void deleteBillionaireById(Integer id) {
        billionaireRepository.deleteById(id);
    }
}

